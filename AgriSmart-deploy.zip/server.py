from pathlib import Path
from io import BytesIO
import json

import numpy as np
import onnxruntime as ort
from PIL import Image
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse


# Paths

ROOT = Path(__file__).resolve().parent

PLANT_GATE_MODEL = (
    ROOT / "models" / "plant_gate" / "plant_gate_v2.onnx"
)

DISEASE_MODEL = (
    ROOT
    / "models"
    / "plant_disease"
    / "plant_disease_finetuned_epoch3.onnx"
)

LABEL_MAP = (
    ROOT
    / "ai_model"
    / "config"
    / "plantvillage_to_model_index.json"
)

INDEX_HTML = ROOT / "index.html"


# Thresholds

PLANT_GATE_THRESHOLD = 0.50
DISEASE_THRESHOLD = 0.55


# App

app = FastAPI(
    title="AgriSmart AI",
    version="2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Check files

if not PLANT_GATE_MODEL.exists():
    raise FileNotFoundError(
        f"Plant Gate V2 not found: {PLANT_GATE_MODEL}"
    )

if not DISEASE_MODEL.exists():
    raise FileNotFoundError(
        f"Disease model not found: {DISEASE_MODEL}"
    )

if not LABEL_MAP.exists():
    raise FileNotFoundError(
        f"Label map not found: {LABEL_MAP}"
    )


# Labels

with open(LABEL_MAP, "r", encoding="utf-8") as f:
    label_map = json.load(f)

id_to_label = {
    int(index): label
    for label, index in label_map.items()
}


# Load models with bounded CPU usage for small cloud instances.

session_options = ort.SessionOptions()
session_options.intra_op_num_threads = 1
session_options.inter_op_num_threads = 1

gate_session = ort.InferenceSession(
    str(PLANT_GATE_MODEL),
    sess_options=session_options,
    providers=["CPUExecutionProvider"]
)

disease_session = ort.InferenceSession(
    str(DISEASE_MODEL),
    sess_options=session_options,
    providers=["CPUExecutionProvider"]
)

gate_input = gate_session.get_inputs()[0].name
gate_output = gate_session.get_outputs()[0].name

disease_input = disease_session.get_inputs()[0].name
disease_output = disease_session.get_outputs()[0].name


# Softmax

def softmax(logits):
    logits = logits - np.max(
        logits,
        axis=1,
        keepdims=True
    )

    exp = np.exp(logits)

    return exp / np.sum(
        exp,
        axis=1,
        keepdims=True
    )


# Plant Gate V2 preprocessing
# Letterbox: preserve whole image and pad to 224x224

def preprocess_gate(image):
    image = image.convert("RGB")

    width, height = image.size

    scale = 224 / max(width, height)

    new_width = max(
        1,
        round(width * scale)
    )

    new_height = max(
        1,
        round(height * scale)
    )

    image = image.resize(
        (new_width, new_height),
        Image.Resampling.BILINEAR
    )

    canvas = Image.new(
        "RGB",
        (224, 224),
        (255, 255, 255)
    )

    x = (224 - new_width) // 2
    y = (224 - new_height) // 2

    canvas.paste(
        image,
        (x, y)
    )

    array = np.asarray(
        canvas,
        dtype=np.float32
    ) / 255.0

    array = (array - 0.5) / 0.5

    array = np.transpose(
        array,
        (2, 0, 1)
    )

    return np.expand_dims(
        array,
        axis=0
    ).astype(np.float32)


# Disease preprocessing
# Must match Epoch 3 training

def preprocess_disease(image):
    image = image.convert("RGB")

    image = image.resize(
        (256, 256),
        Image.Resampling.BILINEAR
    )

    left = (256 - 224) // 2
    top = (256 - 224) // 2

    image = image.crop(
        (
            left,
            top,
            left + 224,
            top + 224
        )
    )

    array = np.asarray(
        image,
        dtype=np.float32
    ) / 255.0

    array = (array - 0.5) / 0.5

    array = np.transpose(
        array,
        (2, 0, 1)
    )

    return np.expand_dims(
        array,
        axis=0
    ).astype(np.float32)


# Helpers

def extract_plant_name(label):
    if label.startswith("Healthy "):
        return label.replace("Healthy ", "").replace(" Plant", "")

    if " with " in label:
        return label.split(" with ")[0]

    return label


def extract_health_name(label):
    if label.startswith("Healthy "):
        return "Healthy"

    if " with " in label:
        return label.split(" with ", 1)[1]

    return label


# Health endpoint

@app.get("/api/health")
def health_check():

    return {
        "status": "ok",
        "plant_gate": True,
        "plant_gate_version": "V2",
        "disease_model": True,
        "disease_model_version": "Epoch 3",
        "plant_gate_threshold": PLANT_GATE_THRESHOLD,
        "disease_threshold": DISEASE_THRESHOLD,
        "disease_classes": len(id_to_label)
    }


# Website

@app.get("/")
def homepage():
    return FileResponse(INDEX_HTML)


# Analysis

@app.post("/api/analyze")
async def analyze(
    image: UploadFile = File(...)
):

    try:

        image_bytes = await image.read()

        if not image_bytes:
            return {
                "status": "uncertain",
                "message": "لم يتم استلام صورة صالحة."
            }

        pil_image = Image.open(
            BytesIO(image_bytes)
        ).convert("RGB")


        # Plant Gate V2

        gate_pixels = preprocess_gate(
            pil_image
        )

        gate_logits = gate_session.run(
            [gate_output],
            {
                gate_input: gate_pixels
            }
        )[0]

        gate_probs = softmax(
            gate_logits
        )[0]

        plant_probability = float(
            gate_probs[1]
        )

        non_plant_probability = float(
            gate_probs[0]
        )


        if plant_probability < PLANT_GATE_THRESHOLD:

            return {
                "status": "no_plant",
                "message": (
                    "لم يتمكن محرك التحقق من "
                    "تأكيد وجود نبات واضح."
                ),
                "plant_gate": {
                    "version": "V2",
                    "plant_probability": plant_probability,
                    "non_plant_probability": non_plant_probability,
                    "threshold": PLANT_GATE_THRESHOLD
                }
            }


        # Disease model

        disease_pixels = preprocess_disease(
            pil_image
        )

        disease_logits = disease_session.run(
            [disease_output],
            {
                disease_input: disease_pixels
            }
        )[0]

        disease_probs = softmax(
            disease_logits
        )[0]

        order = np.argsort(
            disease_probs
        )[::-1]

        top1_index = int(order[0])
        top2_index = int(order[1])

        top1_probability = float(
            disease_probs[top1_index]
        )

        top2_probability = float(
            disease_probs[top2_index]
        )

        margin = (
            top1_probability
            - top2_probability
        )

        predicted_label = id_to_label[
            top1_index
        ]

        second_label = id_to_label[
            top2_index
        ]

        plant_name = extract_plant_name(
            predicted_label
        )

        health_name = extract_health_name(
            predicted_label
        )


        # Low confidence

        if top1_probability < DISEASE_THRESHOLD:

            return {
                "status": "uncertain",
                "message": (
                    "تم تأكيد وجود نبات، لكن "
                    "ثقة نموذج الأمراض غير كافية "
                    "لتقديم تشخيص موثوق."
                ),

                "plant_gate": {
                    "version": "V2",
                    "plant_probability": plant_probability,
                    "threshold": PLANT_GATE_THRESHOLD
                },

                "plant": {
                    "name": plant_name,
                    "confidence": plant_probability
                },

                "health": {
                    "confidence": top1_probability,
                    "threshold": DISEASE_THRESHOLD
                },

                "top_prediction": {
                    "label": predicted_label,
                    "confidence": top1_probability
                },

                "alternative": {
                    "label": second_label,
                    "confidence": top2_probability
                },

                "margin": margin
            }


        # Successful diagnosis

        return {
            "status": "ok",
            "message": "تم تحليل الصورة بنجاح.",

            "plant_gate": {
                "version": "V2",
                "plant_probability": plant_probability,
                "threshold": PLANT_GATE_THRESHOLD
            },

            "plant": {
                "name": plant_name,
                "confidence": plant_probability
            },

            "health": {
                "name": health_name,
                "name_ar": health_name,
                "confidence": top1_probability,
                "threshold": DISEASE_THRESHOLD
            },

            "prediction": {
                "label": predicted_label,
                "confidence": top1_probability
            },

            "alternative": {
                "label": second_label,
                "confidence": top2_probability
            },

            "margin": margin,

            "model": {
                "name": "MobileNetV2 Plant Disease",
                "version": "Epoch 3",
                "classes": len(id_to_label)
            }
        }


    except Exception as e:

        return {
            "status": "error",
            "message": (
                "حدث خطأ أثناء تحليل الصورة: "
                f"{str(e)}"
            )
        }
